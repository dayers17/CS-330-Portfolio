#version 330 core
out vec4 fragmentColor;

in vec3 fragmentPosition;
in vec3 fragmentVertexNormal;
in vec2 fragmentTextureCoordinate;

struct Material {
    vec3 diffuseColor;
    vec3 specularColor;
    float shininess;
}; 

struct DirectionalLight {
    vec3 direction;
	
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;

    bool bActive;
};

struct PointLight {
    vec3 position;
    
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;

    bool bActive;
};

struct SpotLight {
    vec3 position;
    vec3 direction;
    float cutOff;
    float outerCutOff;
  
    float constant;
    float linear;
    float quadratic;
  
    vec3 ambient;
    vec3 diffuse;
    vec3 specular;       

    bool bActive;
};

#define TOTAL_POINT_LIGHTS 5

uniform bool bUseTexture=false;
uniform bool bUseLighting=false;
uniform vec4 objectColor = vec4(1.0f);
uniform vec3 viewPosition;
uniform DirectionalLight directionalLight;
uniform PointLight pointLights[TOTAL_POINT_LIGHTS];
uniform SpotLight spotLight;
uniform Material material;
uniform sampler2D objectTexture;
uniform vec2 UVscale = vec2(1.0f, 1.0f);

// second texture blended over the first in the same pass. It is placed
// with the shape's untiled 0 to 1 UVs: overlayCenter is where it goes
// and overlaySize is how much of the shape it covers.
uniform bool bUseOverlay = false;
uniform sampler2D overlayTexture;
uniform vec2 overlayCenter = vec2(0.5f, 0.5f);
uniform vec2 overlaySize = vec2(1.0f, 1.0f);

// MODIFIED (Milestone Five): every texture lookup uses UVscale, so the
// tiled desk and mug keep their tiling when lighting is on.
//
// MODIFIED (Final Project): the surface color is now worked out once in
// GetSurfaceColor() and passed to each light function. The starter looked
// the texture up again in every light function, three times per light, so
// this is faster and means the overlay only has to be added in one place.

// function prototypes
vec4 GetSurfaceColor();
vec3 CalcDirectionalLight(DirectionalLight light, vec3 normal, vec3 viewDir, vec3 surfaceColor);
vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 surfaceColor);
vec3 CalcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 surfaceColor);

void main()
{
    vec4 surfaceColor = GetSurfaceColor();

    if(bUseLighting == true)
    {
        vec3 phongResult = vec3(0.0f);
        vec3 norm = normalize(fragmentVertexNormal);
        vec3 viewDir = normalize(viewPosition - fragmentPosition);

        // lighting is added up in 3 phases: directional, point lights, and
        // the spotlight. Each light that is turned on adds its ambient,
        // diffuse, and specular parts to this fragment's color.
        if(directionalLight.bActive == true)
        {
            phongResult += CalcDirectionalLight(directionalLight, norm, viewDir, surfaceColor.rgb);
        }
        for(int i = 0; i < TOTAL_POINT_LIGHTS; i++)
        {
            if(pointLights[i].bActive == true)
            {
                phongResult += CalcPointLight(pointLights[i], norm, fragmentPosition, viewDir, surfaceColor.rgb);
            }
        }
        if(spotLight.bActive == true)
        {
            phongResult += CalcSpotLight(spotLight, norm, fragmentPosition, viewDir, surfaceColor.rgb);
        }

        fragmentColor = vec4(phongResult, surfaceColor.a);
    }
    else
    {
        fragmentColor = surfaceColor;
    }
}

// returns the color of the surface before lighting: the texture (tiled by
// UVscale) or the solid object color, with the overlay blended on top
vec4 GetSurfaceColor()
{
    if(bUseTexture == false)
    {
        return objectColor;
    }

    vec4 baseColor = texture(objectTexture, fragmentTextureCoordinate * UVscale);

    if(bUseOverlay == true)
    {
        // map the shape's UVs into the overlay's own 0 to 1 range
        vec2 overlayUV = (fragmentTextureCoordinate - overlayCenter) / overlaySize + vec2(0.5f);

        // 1 inside the overlay's area and 0 outside, so it shows only once
        // instead of repeating. The texture is sampled either way, because
        // sampling inside an if can blur the edges on some graphics cards.
        vec2 inside = step(vec2(0.0f), overlayUV) * step(overlayUV, vec2(1.0f));
        vec4 overlayColor = texture(overlayTexture, overlayUV);

        // the overlay's alpha decides how much of it covers the base
        float blend = overlayColor.a * inside.x * inside.y;
        baseColor.rgb = mix(baseColor.rgb, overlayColor.rgb, blend);
    }

    return baseColor;
}

// calculates the color when using a directional light
vec3 CalcDirectionalLight(DirectionalLight light, vec3 normal, vec3 viewDir, vec3 surfaceColor)
{
    vec3 lightDirection = normalize(-light.direction);
    // diffuse shading
    float diff = max(dot(normal, lightDirection), 0.0);
    // specular shading
    vec3 reflectDir = reflect(-lightDirection, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

    vec3 ambient = light.ambient * surfaceColor;
    vec3 diffuse = light.diffuse * diff * material.diffuseColor * surfaceColor;
    vec3 specular = light.specular * spec * material.specularColor;

    return (ambient + diffuse + specular);
}

// calculates the color when using a point light
vec3 CalcPointLight(PointLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 surfaceColor)
{
    vec3 lightDir = normalize(light.position - fragPos);
    // diffuse shading
    float diff = max(dot(normal, lightDir), 0.0);
    // specular shading
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);

    vec3 ambient = light.ambient * surfaceColor;
    vec3 diffuse = light.diffuse * diff * material.diffuseColor * surfaceColor;
    vec3 specular = light.specular * spec * material.specularColor;

    return (ambient + diffuse + specular);
}

// calculates the color when using a spotlight
vec3 CalcSpotLight(SpotLight light, vec3 normal, vec3 fragPos, vec3 viewDir, vec3 surfaceColor)
{
    vec3 lightDir = normalize(light.position - fragPos);
    // diffuse shading
    float diff = max(dot(normal, lightDir), 0.0);
    // specular shading
    vec3 reflectDir = reflect(-lightDir, normal);
    float spec = pow(max(dot(viewDir, reflectDir), 0.0), material.shininess);
    // attenuation: the light fades with distance
    float distance = length(light.position - fragPos);
    float attenuation = 1.0 / (light.constant + light.linear * distance + light.quadratic * (distance * distance));
    // spotlight intensity: full inside cutOff, fading to 0 at outerCutOff
    float theta = dot(lightDir, normalize(-light.direction));
    float epsilon = light.cutOff - light.outerCutOff;
    float intensity = clamp((theta - light.outerCutOff) / epsilon, 0.0, 1.0);

    // specular is the light's color, not the texture's, so highlights
    // look like reflections on the surface (this matches the point lights)
    vec3 ambient = light.ambient * surfaceColor;
    vec3 diffuse = light.diffuse * diff * material.diffuseColor * surfaceColor;
    vec3 specular = light.specular * spec * material.specularColor;

    return (ambient + diffuse + specular) * attenuation * intensity;
}
