///////////////////////////////////////////////////////////////////////////////
// scenemanager.h
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Dury Ayers
//	Milestone Four, Oct. 2026: textured desk scene with a laptop,
//	coffee mug, and smartphone, one render method per object
//	Milestone Five, Oct. 2026: Phong lighting with a warm key light,
//	a cool fill light, and an overhead desk lamp spotlight, plus a
//	material for every surface in the scene
//	Final Project, Oct. 2026: every object is now its own class (see
//	DeskObjects.h), and this class draws any of them with one loop.
//	Adds a notepad and pens, a laptop keyboard, and a coffee ring
//	blended into the desk with a second texture in the same shader
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "ShapeMeshes.h"
#include "DeskObjects.h"

#include <memory>
#include <string>
#include <vector>

/***********************************************************
 *  SceneManager
 *
 *  This class contains the code for preparing and rendering
 *  3D scenes, including the shader settings.
 ***********************************************************/
class SceneManager
{
public:
	// constructor
	SceneManager(ShaderManager* pShaderManager);
	// destructor
	~SceneManager();

	struct TEXTURE_INFO
	{
		std::string tag;
		uint32_t ID;
	};

	struct OBJECT_MATERIAL
	{
		float ambientStrength;
		glm::vec3 ambientColor;
		glm::vec3 diffuseColor;
		glm::vec3 specularColor;
		float shininess;
		std::string tag;
	};

	// settings for one point light. A point light shines in every
	// direction from its position, like a bare bulb.
	struct POINT_LIGHT
	{
		glm::vec3 position;
		glm::vec3 ambient;		// even fill light that reaches every surface
		glm::vec3 diffuse;		// main light color, strongest on faces turned toward it
		glm::vec3 specular;		// color of the shiny highlights it creates
	};

	// settings for a spotlight. A spotlight shines in a cone from its
	// position, like a desk lamp, and fades out with distance.
	struct SPOT_LIGHT
	{
		glm::vec3 position;
		glm::vec3 direction;		// where the cone points
		float innerConeDegrees;		// full brightness inside this angle
		float outerConeDegrees;		// fades to dark between inner and outer
		float constant;			// distance falloff terms used by the shader:
		float linear;			// brightness = 1 / (constant + linear * d
		float quadratic;		//                + quadratic * d * d)
		glm::vec3 ambient;
		glm::vec3 diffuse;
		glm::vec3 specular;
	};

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// pointer to basic shapes object
	ShapeMeshes* m_basicMeshes;
	// total number of loaded textures
	int m_loadedTextures;
	// loaded textures info
	TEXTURE_INFO m_textureIDs[16];
	// defined object materials
	std::vector<OBJECT_MATERIAL> m_objectMaterials;
	// every object in the scene, drawn in this order each frame
	std::vector<std::unique_ptr<DeskObject>> m_sceneObjects;

	// load texture images and convert to OpenGL texture data
	bool CreateGLTexture(const char* filename, std::string tag);
	// bind loaded OpenGL textures to slots in memory
	void BindGLTextures();
	// free the loaded OpenGL textures
	void DestroyGLTextures();
	// find a loaded texture by tag
	int FindTextureID(std::string tag);
	int FindTextureSlot(std::string tag);
	// find a defined material by tag
	bool FindMaterial(std::string tag, OBJECT_MATERIAL& material);

	// set the transformation values 
	// into the transform buffer
	void SetTransformations(
		glm::vec3 scaleXYZ,
		float XrotationDegrees,
		float YrotationDegrees,
		float ZrotationDegrees,
		glm::vec3 positionXYZ);

	// set the color values into the shader
	void SetShaderColor(
		float redColorValue,
		float greenColorValue,
		float blueColorValue,
		float alphaValue);

	// set the texture data into the shader
	void SetShaderTexture(
		std::string textureTag);

	// set the UV scale for the texture mapping
	void SetTextureUVScale(
		float u, float v);

	// set the object material into the shader
	void SetShaderMaterial(
		std::string materialTag);

public:

	// The following methods are for the students to 
	// customize for their own 3D scene
	void PrepareScene();
	void RenderScene();

	// loads textures from image files
	void LoadSceneTextures();

	// pre-define the object materials for lighting
	void DefineObjectMaterials();
	// pre-set the light sources for the 3D scene
	void SetupSceneLights();

private:

	// send one point light's settings to the shader and turn it on
	void SetPointLight(int index, const POINT_LIGHT& light);
	// send the spotlight's settings to the shader and turn it on
	void SetSpotLight(const SPOT_LIGHT& light);

	// set a finished model matrix into the shader
	void SetModelMatrix(const glm::mat4& modelMatrix);

	// set a texture and its UV scale for the next draw, falling
	// back to a solid color if the texture failed to load
	void ApplyTexture(const std::string& textureTag, glm::vec2 uvScale);

	// turn the second, blended texture on for the next draw, or
	// off if the part has no overlay
	void ApplyOverlay(const TextureOverlay& overlay);

	// create every object in the scene and set where it sits
	void BuildSceneObjects();

	// draw every part of one object
	void DrawObject(const DeskObject& object);

	// draw one basic mesh
	void DrawMesh(MeshType mesh);
};