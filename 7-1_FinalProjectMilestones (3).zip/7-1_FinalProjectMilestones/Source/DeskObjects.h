///////////////////////////////////////////////////////////////////////////////
// deskobjects.h
// ============
// reusable 3D objects for the desk scene
//
//  AUTHOR: Dury Ayers
//	Created for CS-330-Computational Graphics and Visualization, Oct. 2026
//	Final Project: each real world object in the scene is its own class.
//	An object is a list of parts, and each part is one basic mesh with its
//	own transform, texture, and material. All part positions are measured
//	from the object's own origin, so a whole object can be moved, turned,
//	or scaled with one Placement value and drawn as many times as needed.
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include <glm/glm.hpp>

#include <string>
#include <vector>

/***********************************************************
 *  Texture and material tags
 *
 *  These names link the objects to the images and materials
 *  the SceneManager loads, so a tag only has to be typed in
 *  one place. They are const char* so they work in C++14.
 ***********************************************************/
namespace SceneTags
{
	// textures
	const char* const TEX_DESK = "deskWood";
	const char* const TEX_COFFEE_STAIN = "coffeeStain";
	const char* const TEX_ALUMINUM = "brushedAluminum";
	const char* const TEX_KEYBOARD = "keyboard";
	const char* const TEX_LAPTOP_SCREEN = "laptopScreen";
	const char* const TEX_MUG_WRAP = "mugPattern";
	const char* const TEX_CERAMIC = "ceramic";
	const char* const TEX_COFFEE = "coffee";
	const char* const TEX_PHONE_CASE = "graphite";
	const char* const TEX_PHONE_SCREEN = "phoneScreen";
	const char* const TEX_NOTEPAD_SHEET = "notepadSheet";
	const char* const TEX_PAPER_STACK = "paperStack";
	const char* const TEX_PEN_BLUE = "penBlue";

	// materials
	const char* const MAT_WOOD = "polishedWood";
	const char* const MAT_ALUMINUM = "aluminum";
	const char* const MAT_SCREEN = "glassScreen";
	const char* const MAT_CERAMIC = "glazedCeramic";
	const char* const MAT_COFFEE = "coffee";
	const char* const MAT_PLASTIC = "mattePlastic";
	const char* const MAT_GLOSSY_PLASTIC = "glossyPlastic";
	const char* const MAT_PAPER = "paper";
}

// the basic meshes a part can be drawn with. The cylinder has
// separate entries for its faces because the mug uses a
// different texture on its side than on its bottom.
enum class MeshType
{
	Plane,
	Box,
	Cylinder,		// top, bottom, and side
	CylinderSide,		// open tube, no caps
	CylinderTop,		// top cap only
	CylinderBottom,		// bottom cap only
	Cone,
	Sphere,
	Torus
};

// scale, rotation, and position for one shape or one object
struct Transform
{
	glm::vec3 scale;
	glm::vec3 rotationDegrees;
	glm::vec3 position;
};

// where a whole object sits on the desk. Objects only turn
// around the vertical (Y) axis, like something set down on a table.
struct Placement
{
	glm::vec3 position;
	float yRotationDegrees;
	float uniformScale;
};

// an optional second texture blended over a part's main texture
// in the same shader pass, used for the coffee ring on the desk
struct TextureOverlay
{
	std::string textureTag;		// empty means no overlay
	glm::vec2 centerUV;		// where the overlay sits on the part's 0 to 1 UVs
	glm::vec2 sizeUV;		// how much of the part's UV space it covers
};

// one basic shape that makes up part of an object
struct ObjectPart
{
	MeshType mesh;
	Transform local;		// measured from the object's origin
	std::string textureTag;
	glm::vec2 uvScale;		// how many times the texture repeats
	std::string materialTag;
	TextureOverlay overlay;
};

/***********************************************************
 *  DeskObject
 *
 *  Base class for every object in the scene. A derived class
 *  only has to add its parts in its constructor. Drawing is
 *  handled in one place by SceneManager::DrawObject(), which
 *  loops over the parts, so no object repeats drawing code.
 ***********************************************************/
class DeskObject
{
public:
	DeskObject(const std::string& name, const Placement& placement);
	virtual ~DeskObject() = default;

	const std::string& GetName() const;
	const std::vector<ObjectPart>& GetParts() const;

	// full model matrix for one part: the object's placement
	// applied on top of the part's local transform
	glm::mat4 GetPartModelMatrix(const ObjectPart& part) const;

	// builds a matrix in the same order as the starter code's
	// SetTransformations(): translate * rotateX * rotateY * rotateZ * scale
	static glm::mat4 BuildMatrix(const Transform& transform);

protected:
	// adds one shape to this object
	void AddPart(
		MeshType mesh,
		const Transform& local,
		const std::string& textureTag,
		const glm::vec2& uvScale,
		const std::string& materialTag);

	// adds a texture overlay to the part that was added last
	void AddOverlayToLastPart(const TextureOverlay& overlay);

private:
	std::string m_name;
	glm::mat4 m_placementMatrix;
	std::vector<ObjectPart> m_parts;
};

/***********************************************************
 *  Objects in the scene
 ***********************************************************/

// the desk top: one large tiled wood plane with a coffee ring
// blended into the wood where a mug once sat
class Desk : public DeskObject
{
public:
	explicit Desk(const Placement& placement);
};

// aluminum base with a keyboard, a tilted lid, and a display
class Laptop : public DeskObject
{
public:
	explicit Laptop(const Placement& placement);
};

// open patterned body, ceramic bottom, coffee surface, and handle
class CoffeeMug : public DeskObject
{
public:
	explicit CoffeeMug(const Placement& placement);
};

// graphite case with a navigation screen on top
class Smartphone : public DeskObject
{
public:
	explicit Smartphone(const Placement& placement);
};

// paper pad, ruled top sheet, and a row of metal binding rings
// placed in a loop. The ring count can change per notepad.
class Notepad : public DeskObject
{
public:
	Notepad(const Placement& placement, int ringCount);
};

// barrel, writing tip, end button, and pocket clip. The barrel
// texture is a parameter so the same class can make pens of
// different colors.
class Pen : public DeskObject
{
public:
	Pen(const Placement& placement, const std::string& barrelTextureTag);
};
