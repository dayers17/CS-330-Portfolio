///////////////////////////////////////////////////////////////////////////////
// deskobjects.cpp
// ============
// builds each object in the desk scene out of basic shapes
//
//  AUTHOR: Dury Ayers
//	Created for CS-330-Computational Graphics and Visualization, Oct. 2026
//
//  Every measurement here is in object space: (0, 0, 0) is the spot
//  where the object touches the desk, under its center. The scene
//  decides where each object goes with a Placement, so none of these
//  numbers change when an object is moved or reused.
///////////////////////////////////////////////////////////////////////////////

#include "DeskObjects.h"

#include <glm/gtx/transform.hpp>

using namespace SceneTags;

namespace
{
	// one copy of the texture across a face
	const glm::vec2 UV_SINGLE = glm::vec2(1.0f, 1.0f);

	// no rotation
	const glm::vec3 NO_ROTATION = glm::vec3(0.0f);

	// a part with no overlay texture
	const TextureOverlay NO_OVERLAY = { "", glm::vec2(0.0f), glm::vec2(1.0f) };

	/*** DESK ***/

	// the plane mesh is 2 x 2 units, so this makes the desk 40 units
	// wide and 20 deep, running past the edges of the view
	const Transform DESK_TOP = { glm::vec3(20.0f, 1.0f, 10.0f), NO_ROTATION, glm::vec3(0.0f) };

	// TILING: the wood is seamless, so it repeats 4 times across the 40
	// unit width and 2 times across the 20 unit depth. Every repeat is a
	// 10 x 10 square, so the boards keep a realistic width.
	const glm::vec2 UV_DESK = glm::vec2(4.0f, 2.0f);

	// TWO TEXTURES IN ONE SHADER: a coffee ring is blended over the wood.
	// It is placed with the desk's untiled 0 to 1 UVs, so it shows up
	// once instead of repeating with the wood. Center (0.665, 0.5) is
	// world spot (6.6, 0), just right of the mug, like the mug was
	// moved. The overlay covers a 2 x 2 unit square (2 / 40 = 0.05 and
	// 2 / 20 = 0.1), and the ring inside it is about as wide as the mug.
	const TextureOverlay DESK_COFFEE_RING =
	{
		TEX_COFFEE_STAIN,
		glm::vec2(0.665f, 0.5f),
		glm::vec2(0.05f, 0.1f)
	};

	/*** LAPTOP ***/

	// base: raised by half its height to sit flat on the desk
	const Transform LAPTOP_BASE = { glm::vec3(6.0f, 0.3f, 4.0f), NO_ROTATION, glm::vec3(0.0f, 0.15f, 0.0f) };

	// keyboard: a plane 0.001 above the base's top (y = 0.3) so it never
	// flickers against it. It covers the back half of the base and leaves
	// the front for the palm rest. 5.2 x 2.0 matches the 1300 x 500 image.
	const Transform LAPTOP_KEYBOARD = { glm::vec3(2.6f, 1.0f, 1.0f), NO_ROTATION, glm::vec3(0.0f, 0.301f, -0.75f) };

	// lid: hinged at the base's back edge (z = -2, y = 0.3) and tilted back
	// 15 degrees, which puts its center 1.93 up and 0.52 back from the hinge
	const Transform LAPTOP_LID = { glm::vec3(6.0f, 4.0f, 0.2f), glm::vec3(-15.0f, 0.0f, 0.0f), glm::vec3(0.0f, 2.23f, -2.52f) };

	// display: the plane mesh faces up, so 90 degrees stands it up and
	// 15 less (75) matches the lid's tilt. It sits 0.105 out from the
	// lid's center along the lid's facing direction, just in front of
	// the lid's surface. 5.6 x 3.64 matches the 1600 x 1040 screen image.
	const Transform LAPTOP_DISPLAY = { glm::vec3(2.8f, 1.0f, 1.82f), glm::vec3(75.0f, 0.0f, 0.0f), glm::vec3(0.0f, 2.257f, -2.419f) };

	// the brushed lines repeat 1.5 times across the 6 x 4 faces so they
	// stay evenly spaced instead of stretched
	const glm::vec2 UV_ALUMINUM = glm::vec2(1.5f, 1.0f);

	/*** COFFEE MUG ***/

	// body: the cylinder mesh starts at y = 0, so it already sits on the desk
	const Transform MUG_BODY = { glm::vec3(0.8f, 1.8f, 0.8f), NO_ROTATION, glm::vec3(0.0f) };

	// coffee: a thin disc just inside the wall, 0.28 below the rim
	const Transform MUG_COFFEE = { glm::vec3(0.76f, 0.02f, 0.76f), NO_ROTATION, glm::vec3(0.0f, 1.5f, 0.0f) };

	// handle: the torus stands in the XY plane, centered just past the
	// wall so only the outer loop shows
	const Transform MUG_HANDLE = { glm::vec3(0.6f, 0.6f, 0.6f), NO_ROTATION, glm::vec3(1.1f, 0.9f, 0.0f) };

	// TILING ON A CURVE: the side wraps 5.03 units around (2 x pi x 0.8)
	// and stands 1.8 tall. Three repeats around makes each one about
	// 1.68 x 1.8, close to the square image, so the pattern is not stretched.
	const glm::vec2 UV_MUG_WRAP = glm::vec2(3.0f, 1.0f);

	/*** SMARTPHONE ***/

	// case: a flat box lying face up
	const Transform PHONE_CASE = { glm::vec3(1.5f, 0.1f, 3.0f), NO_ROTATION, glm::vec3(0.0f, 0.05f, 0.0f) };

	// screen: 0.001 above the case's top face, leaving a thin bezel.
	// 1.36 x 2.8 matches the 1024 x 2112 screen image.
	const Transform PHONE_SCREEN = { glm::vec3(0.68f, 1.0f, 1.4f), NO_ROTATION, glm::vec3(0.0f, 0.101f, 0.0f) };

	/*** NOTEPAD ***/

	// pad: a 3 x 4 stack of paper, 0.25 thick
	const float NOTEPAD_THICKNESS = 0.25f;
	const Transform NOTEPAD_PAD = { glm::vec3(3.0f, NOTEPAD_THICKNESS, 4.0f), NO_ROTATION, glm::vec3(0.0f, NOTEPAD_THICKNESS / 2.0f, 0.0f) };

	// top sheet: a plane 0.0015 above the pad so the ruled lines and the
	// pencil route sketch show only on top. The 3 x 4 size matches the
	// 1024 x 1365 image.
	const Transform NOTEPAD_SHEET = { glm::vec3(1.5f, 1.0f, 2.0f), NO_ROTATION, glm::vec3(0.0f, NOTEPAD_THICKNESS + 0.0015f, 0.0f) };

	// binding rings: each torus is turned 90 degrees so it stands across
	// the back edge, and its center sits on the top surface so half the
	// ring loops over the paper and half is hidden inside the pad, like
	// a ring going through a punched hole.
	const float RING_SCALE = 0.16f;
	const float RING_ROW_Z = -1.82f;			// lines up with the holes in the image
	const float RING_ROW_HALF_WIDTH = 1.2f;		// first and last ring sit 1.2 from center
	const glm::vec3 RING_ROTATION = glm::vec3(0.0f, 90.0f, 0.0f);

	/*** PEN ***/

	// The pen lies along the X axis. The cylinder and cone meshes stand
	// up along Y, so rotating them -90 degrees around Z lays them down
	// pointing toward +X. The barrel radius is 0.07, so every round part
	// is centered 0.07 up to rest on the surface below it.
	const float PEN_RADIUS = 0.07f;
	const float PEN_BARREL_LENGTH = 2.2f;
	const glm::vec3 PEN_LAY_FLAT = glm::vec3(0.0f, 0.0f, -90.0f);

	// barrel: runs from x = -1.1 to x = 1.1
	const Transform PEN_BARREL = { glm::vec3(PEN_RADIUS, PEN_BARREL_LENGTH, PEN_RADIUS), PEN_LAY_FLAT, glm::vec3(-PEN_BARREL_LENGTH / 2.0f, PEN_RADIUS, 0.0f) };

	// writing tip: a cone from the barrel's end out to a point 0.32 further
	const Transform PEN_TIP = { glm::vec3(PEN_RADIUS, 0.32f, PEN_RADIUS), PEN_LAY_FLAT, glm::vec3(PEN_BARREL_LENGTH / 2.0f, PEN_RADIUS, 0.0f) };

	// click button: a small sphere pushed just past the back end
	const Transform PEN_BUTTON = { glm::vec3(0.055f), NO_ROTATION, glm::vec3(-PEN_BARREL_LENGTH / 2.0f - 0.03f, PEN_RADIUS, 0.0f) };

	// pocket clip: a thin metal strip lying along the top of the barrel
	const Transform PEN_CLIP = { glm::vec3(0.9f, 0.025f, 0.035f), NO_ROTATION, glm::vec3(-0.6f, PEN_RADIUS * 2.0f + 0.0125f, 0.0f) };
}

/***********************************************************
 *  DeskObject()
 *
 *  Stores the object's name and turns its placement into a
 *  matrix once, so it is not rebuilt every frame.
 ***********************************************************/
DeskObject::DeskObject(const std::string& name, const Placement& placement)
	: m_name(name)
{
	Transform placementTransform =
	{
		glm::vec3(placement.uniformScale),
		glm::vec3(0.0f, placement.yRotationDegrees, 0.0f),
		placement.position
	};
	m_placementMatrix = BuildMatrix(placementTransform);
}

/***********************************************************
 *  GetName() / GetParts()
 *
 *  Read only access to the object's name and parts.
 ***********************************************************/
const std::string& DeskObject::GetName() const
{
	return m_name;
}

const std::vector<ObjectPart>& DeskObject::GetParts() const
{
	return m_parts;
}

/***********************************************************
 *  GetPartModelMatrix()
 *
 *  The part's local matrix places it inside the object, then
 *  the placement matrix moves the whole object into the world.
 *  Reading right to left: scale and place the part, then turn
 *  and move it along with the rest of the object.
 ***********************************************************/
glm::mat4 DeskObject::GetPartModelMatrix(const ObjectPart& part) const
{
	return m_placementMatrix * BuildMatrix(part.local);
}

/***********************************************************
 *  BuildMatrix()
 *
 *  Turns a scale, rotation, and position into one matrix.
 *  The order matches the starter's SetTransformations(), so
 *  shapes land exactly where they did in earlier milestones.
 ***********************************************************/
glm::mat4 DeskObject::BuildMatrix(const Transform& transform)
{
	glm::mat4 scale = glm::scale(transform.scale);
	glm::mat4 rotationX = glm::rotate(glm::radians(transform.rotationDegrees.x), glm::vec3(1.0f, 0.0f, 0.0f));
	glm::mat4 rotationY = glm::rotate(glm::radians(transform.rotationDegrees.y), glm::vec3(0.0f, 1.0f, 0.0f));
	glm::mat4 rotationZ = glm::rotate(glm::radians(transform.rotationDegrees.z), glm::vec3(0.0f, 0.0f, 1.0f));
	glm::mat4 translation = glm::translate(transform.position);

	return translation * rotationX * rotationY * rotationZ * scale;
}

/***********************************************************
 *  AddPart()
 *
 *  Adds one shape to the object. Overlays are rare, so they
 *  are added separately with AddOverlayToLastPart().
 ***********************************************************/
void DeskObject::AddPart(
	MeshType mesh,
	const Transform& local,
	const std::string& textureTag,
	const glm::vec2& uvScale,
	const std::string& materialTag)
{
	ObjectPart part = { mesh, local, textureTag, uvScale, materialTag, NO_OVERLAY };
	m_parts.push_back(part);
}

/***********************************************************
 *  AddOverlayToLastPart()
 *
 *  Gives the most recently added part a second texture that
 *  the shader blends over the first one.
 ***********************************************************/
void DeskObject::AddOverlayToLastPart(const TextureOverlay& overlay)
{
	if (!m_parts.empty())
	{
		m_parts.back().overlay = overlay;
	}
}

/***********************************************************
 *  Desk
 *
 *  One plane with tiled wood and a coffee ring blended in.
 ***********************************************************/
Desk::Desk(const Placement& placement)
	: DeskObject("Desk", placement)
{
	AddPart(MeshType::Plane, DESK_TOP, TEX_DESK, UV_DESK, MAT_WOOD);
	AddOverlayToLastPart(DESK_COFFEE_RING);
}

/***********************************************************
 *  Laptop
 *
 *  Four parts: two aluminum boxes for the base and lid, a
 *  keyboard plane on the base, and a display plane on the lid.
 *  The keyboard and display are separate planes so their
 *  images show only on the one face where they belong, while
 *  the rest of the laptop stays brushed metal.
 ***********************************************************/
Laptop::Laptop(const Placement& placement)
	: DeskObject("Laptop", placement)
{
	AddPart(MeshType::Box, LAPTOP_BASE, TEX_ALUMINUM, UV_ALUMINUM, MAT_ALUMINUM);
	AddPart(MeshType::Plane, LAPTOP_KEYBOARD, TEX_KEYBOARD, UV_SINGLE, MAT_PLASTIC);
	AddPart(MeshType::Box, LAPTOP_LID, TEX_ALUMINUM, UV_ALUMINUM, MAT_ALUMINUM);
	AddPart(MeshType::Plane, LAPTOP_DISPLAY, TEX_LAPTOP_SCREEN, UV_SINGLE, MAT_SCREEN);
}

/***********************************************************
 *  CoffeeMug
 *
 *  The body is drawn as an open tube (no top cap) so the
 *  coffee inside is visible, plus a plain ceramic bottom,
 *  the coffee surface, and a torus handle.
 ***********************************************************/
CoffeeMug::CoffeeMug(const Placement& placement)
	: DeskObject("Coffee mug", placement)
{
	AddPart(MeshType::CylinderSide, MUG_BODY, TEX_MUG_WRAP, UV_MUG_WRAP, MAT_CERAMIC);
	AddPart(MeshType::CylinderBottom, MUG_BODY, TEX_CERAMIC, UV_SINGLE, MAT_CERAMIC);
	AddPart(MeshType::CylinderTop, MUG_COFFEE, TEX_COFFEE, UV_SINGLE, MAT_COFFEE);
	AddPart(MeshType::Torus, MUG_HANDLE, TEX_CERAMIC, UV_SINGLE, MAT_CERAMIC);
}

/***********************************************************
 *  Smartphone
 *
 *  A matte graphite case with a glass screen showing turn by
 *  turn directions.
 ***********************************************************/
Smartphone::Smartphone(const Placement& placement)
	: DeskObject("Smartphone", placement)
{
	AddPart(MeshType::Box, PHONE_CASE, TEX_PHONE_CASE, UV_SINGLE, MAT_PLASTIC);
	AddPart(MeshType::Plane, PHONE_SCREEN, TEX_PHONE_SCREEN, UV_SINGLE, MAT_SCREEN);
}

/***********************************************************
 *  Notepad
 *
 *  A paper pad, a ruled top sheet, and a row of binding rings.
 *  The rings are added in a loop, spaced evenly across the
 *  back edge, so changing ringCount changes the binding
 *  without adding or removing any lines of code.
 ***********************************************************/
Notepad::Notepad(const Placement& placement, int ringCount)
	: DeskObject("Notepad", placement)
{
	AddPart(MeshType::Box, NOTEPAD_PAD, TEX_PAPER_STACK, UV_SINGLE, MAT_PAPER);
	AddPart(MeshType::Plane, NOTEPAD_SHEET, TEX_NOTEPAD_SHEET, UV_SINGLE, MAT_PAPER);

	// at least two rings are needed to space them across the edge
	if (ringCount < 2)
	{
		ringCount = 2;
	}

	float spacing = (RING_ROW_HALF_WIDTH * 2.0f) / static_cast<float>(ringCount - 1);
	for (int i = 0; i < ringCount; i++)
	{
		Transform ring =
		{
			glm::vec3(RING_SCALE),
			RING_ROTATION,
			glm::vec3(-RING_ROW_HALF_WIDTH + spacing * i, NOTEPAD_THICKNESS, RING_ROW_Z)
		};
		AddPart(MeshType::Torus, ring, TEX_ALUMINUM, UV_SINGLE, MAT_ALUMINUM);
	}
}

/***********************************************************
 *  Pen
 *
 *  A glossy barrel (cylinder), a metal writing tip (cone),
 *  a click button (sphere), and a pocket clip (box). The
 *  barrel texture is passed in, so one class makes any color
 *  of pen.
 ***********************************************************/
Pen::Pen(const Placement& placement, const std::string& barrelTextureTag)
	: DeskObject("Pen", placement)
{
	AddPart(MeshType::Cylinder, PEN_BARREL, barrelTextureTag, UV_SINGLE, MAT_GLOSSY_PLASTIC);
	AddPart(MeshType::Cone, PEN_TIP, TEX_ALUMINUM, UV_SINGLE, MAT_ALUMINUM);
	AddPart(MeshType::Sphere, PEN_BUTTON, TEX_ALUMINUM, UV_SINGLE, MAT_ALUMINUM);
	AddPart(MeshType::Box, PEN_CLIP, TEX_ALUMINUM, UV_SINGLE, MAT_ALUMINUM);
}
