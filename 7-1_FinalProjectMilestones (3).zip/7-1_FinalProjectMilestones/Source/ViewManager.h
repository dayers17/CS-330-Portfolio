///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Dury Ayers
//	Milestone Three, Sept. 2026: WASD/QE movement, mouse look, scroll
//	wheel speed, and P/O perspective and orthographic switching
//	Final Project, Oct. 2026: prints the controls in the console and
//	logs camera stops, speed changes, and view changes
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h" 

class ViewManager
{
public:
	// constructor
	ViewManager(
		ShaderManager* pShaderManager);
	// destructor
	~ViewManager();

	// mouse position callback for mouse interaction with the 3D scene
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

	// mouse scroll callback for adjusting camera movement speed
	static void Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset);

private:
	// pointer to shader manager object
	ShaderManager* m_pShaderManager;
	// active OpenGL display window
	GLFWwindow* m_pWindow;

	// process keyboard events for interaction with the 3D scene
	void ProcessKeyboardEvents();

	// WASD and QE camera movement
	void ProcessCameraMovement();

	// P and O keys for switching between perspective and orthographic
	void ProcessProjectionKeys();

	// H key prints the controls again
	void ProcessHelpKey();

	// build the projection matrix for the currently selected view
	glm::mat4 GetProjectionMatrix();

	// print the keyboard and mouse controls in the console
	static void PrintControls();

	// print the camera's position and direction in the console
	static void LogCameraPosition(const char* reason);

public:
	// create the initial OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);
	
	// prepare the conversion from 3D object display to 2D scene display
	void PrepareSceneView();
};