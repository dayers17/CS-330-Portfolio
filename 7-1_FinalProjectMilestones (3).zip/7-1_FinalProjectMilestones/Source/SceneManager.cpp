///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Dury Ayers
//	Milestone Four, Oct. 2026: loads eight textures and maps them
//	onto the desk, laptop, coffee mug, and smartphone
//	Milestone Five, Oct. 2026: adds Phong lighting (two point lights
//	and a spotlight) and gives every surface a material so the light
//	reacts to wood, metal, glass, ceramic, coffee, and plastic
//	differently
//	Final Project, Oct. 2026: the objects moved into their own classes
//	(DeskObjects.h) and are drawn with one loop. Adds a notepad, two
//	pens, a laptop keyboard, a coffee ring blended into the desk with a
//	second texture, a back light, correct normals for rotated shapes, and texture
//	clean up when the program closes
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>
#include <fstream>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
	const char* g_UVScaleName = "UVscale";

	// shader uniforms for the second (overlay) texture
	const char* g_UseOverlayName = "bUseOverlay";
	const char* g_OverlayTextureName = "overlayTexture";
	const char* g_OverlayCenterName = "overlayCenter";
	const char* g_OverlaySizeName = "overlaySize";

	// OpenGL guarantees 16 texture slots for one shader
	const int MAX_TEXTURES = 16;

	/*** TEXTURE SETTINGS ***/

	// folders to search for the texture images, relative to the
	// project folder that Visual Studio runs the program from.
	// The Codio copy keeps shaders inside each project, so the
	// images go in a "textures" folder next to "shaders" and ship
	// inside the submitted ZIP. The shared Utilities folder from
	// the downloadable course content is checked second.
	const std::string TEXTURE_FOLDERS[] =
	{
		"textures/",
		"../../Utilities/textures/"
	};

	// pairs each image file with the tag it gets stored under
	struct SCENE_TEXTURE
	{
		std::string fileName;
		std::string tag;
	};

	// every texture the scene uses (OpenGL allows up to 16 slots).
	// All thirteen images were made for this project, so there are no
	// licensing limits on them. The tags live in DeskObjects.h so the
	// objects and this list always use the same names.
	const SCENE_TEXTURE SCENE_TEXTURES[] =
	{
		{ "desk_wood.jpg", SceneTags::TEX_DESK },
		{ "coffee_stain.png", SceneTags::TEX_COFFEE_STAIN },	// has transparency
		{ "brushed_aluminum.jpg", SceneTags::TEX_ALUMINUM },
		{ "keyboard.jpg", SceneTags::TEX_KEYBOARD },
		{ "laptop_screen.jpg", SceneTags::TEX_LAPTOP_SCREEN },
		{ "mug_pattern.jpg", SceneTags::TEX_MUG_WRAP },
		{ "ceramic.jpg", SceneTags::TEX_CERAMIC },
		{ "coffee.jpg", SceneTags::TEX_COFFEE },
		{ "graphite.jpg", SceneTags::TEX_PHONE_CASE },
		{ "phone_screen.jpg", SceneTags::TEX_PHONE_SCREEN },
		{ "notepad_paper.jpg", SceneTags::TEX_NOTEPAD_SHEET },
		{ "paper_stack.jpg", SceneTags::TEX_PAPER_STACK },
		{ "pen_blue.jpg", SceneTags::TEX_PEN_BLUE }
	};
	const int SCENE_TEXTURE_COUNT =
		static_cast<int>(sizeof(SCENE_TEXTURES) / sizeof(SCENE_TEXTURES[0]));

	// returns the first folder in TEXTURE_FOLDERS that holds the
	// scene's first image, so textures load from wherever they are
	// without printing false "Could not load" errors along the way
	std::string FindTextureFolder()
	{
		for (const std::string& folder : TEXTURE_FOLDERS)
		{
			std::ifstream testFile(folder + SCENE_TEXTURES[0].fileName);
			if (testFile.good())
			{
				return folder;
			}
		}

		// nothing found, so use the first folder and let the load
		// errors show exactly which files are missing
		return TEXTURE_FOLDERS[0];
	}

	// solid gray used if a texture image fails to load
	const glm::vec4 MISSING_TEXTURE_COLOR = glm::vec4(0.5f, 0.5f, 0.5f, 1.0f);

	/*** OBJECT PLACEMENTS (position, turn around Y in degrees, scale) ***/

	// Each object's shapes are measured from its own origin in
	// DeskObjects.cpp, so these lines are the only place that decides
	// where things sit on the desk. Moving an object, or adding another
	// copy, takes one line.
	const Placement DESK_PLACEMENT = { glm::vec3(0.0f, 0.0f, 0.0f), 0.0f, 1.0f };
	const Placement LAPTOP_PLACEMENT = { glm::vec3(-3.0f, 0.0f, 0.0f), 0.0f, 1.0f };
	const Placement MUG_PLACEMENT = { glm::vec3(4.0f, 0.0f, 0.5f), 0.0f, 1.0f };
	const Placement PHONE_PLACEMENT = { glm::vec3(1.5f, 0.0f, 2.5f), 15.0f, 1.0f };

	// the notepad sits front right, turned a little toward the laptop
	const Placement NOTEPAD_PLACEMENT = { glm::vec3(6.0f, 0.0f, 4.0f), -12.0f, 1.0f };
	const int NOTEPAD_RING_COUNT = 9;

	// the blue pen rests on the notepad's top sheet (0.2515 up), and
	// the black pen lies on the desk between the phone and notepad.
	// Both come from the same Pen class with a different barrel texture.
	const Placement BLUE_PEN_PLACEMENT = { glm::vec3(6.1f, 0.253f, 4.4f), 30.0f, 1.0f };
	const Placement BLACK_PEN_PLACEMENT = { glm::vec3(3.6f, 0.0f, 3.6f), 78.0f, 1.0f };

	/*** MATERIALS (how each surface reacts to light) ***/

	using namespace SceneTags;

	// Each material is listed as: ambient strength, ambient color,
	// diffuse color, specular color, shininess, tag.
	//   diffuse   = how much of the light's color the surface shows.
	//               With a texture, this scales the image's brightness.
	//   specular  = strength and color of the shiny highlight
	//   shininess = how tight the highlight is (higher = smaller and
	//               sharper, like glass; lower = wide and soft, like wood)
	// This project's shader takes its ambient light from the lights
	// themselves, so the two ambient values are kept only to fill the
	// OBJECT_MATERIAL struct that SetShaderMaterial() expects.
	const SceneManager::OBJECT_MATERIAL SCENE_MATERIALS[] =
	{
		// desk: varnished wood with a soft, wide sheen so the lights
		// show as visible reflections across the plane
		{ 0.2f, glm::vec3(0.2f), glm::vec3(0.75f), glm::vec3(0.35f), 16.0f, MAT_WOOD },

		// laptop body: brushed metal with a bright, fairly tight highlight
		{ 0.2f, glm::vec3(0.2f), glm::vec3(0.8f), glm::vec3(0.7f), 48.0f, MAT_ALUMINUM },

		// laptop and phone displays: full diffuse so the screen images
		// stay bright, plus a small sharp glare like glass
		{ 0.3f, glm::vec3(0.3f), glm::vec3(1.0f), glm::vec3(0.6f), 90.0f, MAT_SCREEN },

		// mug and handle: glazed ceramic, glossy but softer than glass
		{ 0.2f, glm::vec3(0.2f), glm::vec3(0.85f), glm::vec3(0.5f), 40.0f, MAT_CERAMIC },

		// coffee: dark liquid with a very sharp wet highlight
		{ 0.1f, glm::vec3(0.1f), glm::vec3(0.7f), glm::vec3(0.8f), 96.0f, MAT_COFFEE },

		// phone case: matte plastic with only a faint, wide highlight
		{ 0.2f, glm::vec3(0.2f), glm::vec3(0.7f), glm::vec3(0.2f), 12.0f, MAT_PLASTIC },

		// pen barrel: glossy plastic with a bright, tight highlight that
		// runs along the length of the barrel
		{ 0.2f, glm::vec3(0.2f), glm::vec3(0.85f), glm::vec3(0.6f), 64.0f, MAT_GLOSSY_PLASTIC },

		// notepad paper: almost no shine at all, so it reads as matte
		{ 0.2f, glm::vec3(0.2f), glm::vec3(0.9f), glm::vec3(0.06f), 4.0f, MAT_PAPER }
	};
	const int SCENE_MATERIAL_COUNT =
		static_cast<int>(sizeof(SCENE_MATERIALS) / sizeof(SCENE_MATERIALS[0]));

	/*** LIGHTS ***/

	// The scene uses a classic three point setup (key, fill, and back
	// light) plus a desk lamp. Combined, the lights reach every side of
	// every object, so nothing turns black when the camera circles around.

	// KEY LIGHT: warm white, high up and to the front right, like
	// daylight from a window. It does most of the shading and puts
	// highlights on the metal, screens, mug, and coffee.
	const SceneManager::POINT_LIGHT KEY_LIGHT =
	{
		glm::vec3(6.0f, 12.0f, 8.0f),		// position
		glm::vec3(0.15f, 0.14f, 0.12f),		// ambient
		glm::vec3(0.7f, 0.65f, 0.55f),		// diffuse (warm white)
		glm::vec3(0.6f, 0.6f, 0.55f)		// specular
	};

	// FILL LIGHT: cool blue, lower and from the left. It brightens the
	// left sides the key light misses (the laptop's left edge, the mug's
	// left side) and adds color contrast against the warm key light.
	const SceneManager::POINT_LIGHT FILL_LIGHT =
	{
		glm::vec3(-12.0f, 5.0f, 6.0f),		// position
		glm::vec3(0.04f, 0.05f, 0.08f),		// ambient (slight blue tint)
		glm::vec3(0.25f, 0.3f, 0.45f),		// diffuse (cool blue)
		glm::vec3(0.1f, 0.12f, 0.2f)		// specular
	};

	// BACK LIGHT: neutral white, high up and behind the desk. Without it
	// the back of the laptop lid only gets ambient light and looks almost
	// black when the camera moves behind the scene. It also outlines the
	// back edges of the mug and notepad.
	const SceneManager::POINT_LIGHT BACK_LIGHT =
	{
		glm::vec3(2.0f, 9.0f, -12.0f),		// position
		glm::vec3(0.03f, 0.03f, 0.03f),		// ambient
		glm::vec3(0.4f, 0.4f, 0.42f),		// diffuse (neutral white)
		glm::vec3(0.25f, 0.25f, 0.25f)		// specular
	};

	// DESK LAMP: a warm spotlight straight above the desk, angled a
	// little toward the back. It makes a brighter pool of light over
	// the laptop, phone, and mug that fades out toward the desk's
	// edges. The falloff values give about half brightness at the
	// desk, 10 units below the lamp.
	const SceneManager::SPOT_LIGHT DESK_LAMP =
	{
		glm::vec3(0.0f, 10.0f, 2.0f),		// position
		glm::vec3(0.0f, -1.0f, -0.15f),		// direction (down, tilted back)
		22.0f,					// inner cone angle (degrees)
		35.0f,					// outer cone angle (degrees)
		1.0f,					// constant falloff
		0.045f,					// linear falloff
		0.0075f,				// quadratic falloff
		glm::vec3(0.0f, 0.0f, 0.0f),		// ambient (none, the cone only)
		glm::vec3(0.65f, 0.58f, 0.45f),		// diffuse (warm lamp color)
		glm::vec3(0.5f, 0.45f, 0.4f)		// specular
	};
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// initialize the texture collection. This block matches the
	// 5-2 starter. The 7-1 starter left m_loadedTextures unset,
	// which would make the first texture load write to a random slot.
	for (int i = 0; i < MAX_TEXTURES; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// free the texture memory on the graphics card
	DestroyGLTextures();

	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// all 16 slots are full, so there is nowhere to store another texture
	if (m_loadedTextures >= MAX_TEXTURES)
	{
		std::cout << "Could not load image:" << filename << ", all " << MAX_TEXTURES << " texture slots are in use" << std::endl;
		return false;
	}

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			// MODIFIED: free the image so an unsupported file does not leak memory
			stbi_image_free(image);
			glBindTexture(GL_TEXTURE_2D, 0);
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	// MODIFIED: the starter called glGenTextures() here, which makes new
	// textures instead of freeing the old ones. glDeleteTextures() frees them.
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	// size_t matches the type size() returns, which clears the
	// signed/unsigned compiler warning the starter code produced
	size_t index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	// MODIFIED: the starter returned true even when no material
	// matched, which sent uninitialized values to the shader. Returning
	// bFound means a mistyped tag is simply skipped instead.
	return(bFound);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value(g_UVScaleName, glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
 *  SetModelMatrix()
 *
 *  Sends a finished model matrix to the shader. The objects
 *  build their own matrices (see DeskObject), so this skips
 *  the separate scale, rotation, and position arguments that
 *  SetTransformations() takes.
 ***********************************************************/
void SceneManager::SetModelMatrix(const glm::mat4& modelMatrix)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelMatrix);
	}
}

/***********************************************************
 *  ApplyTexture()
 *
 *  This method sets the texture and UV scale for the next
 *  draw call. The UV scale is set every time because it stays
 *  in the shader until changed, so the tiled desk would
 *  otherwise make every shape drawn after it tile too.
 ***********************************************************/
void SceneManager::ApplyTexture(const std::string& textureTag, glm::vec2 uvScale)
{
	// if the texture never loaded, draw the shape in solid gray
	// so it still shows up instead of sampling an empty slot
	if (FindTextureSlot(textureTag) < 0)
	{
		SetShaderColor(
			MISSING_TEXTURE_COLOR.r,
			MISSING_TEXTURE_COLOR.g,
			MISSING_TEXTURE_COLOR.b,
			MISSING_TEXTURE_COLOR.a);
		return;
	}

	SetShaderTexture(textureTag);
	SetTextureUVScale(uvScale.x, uvScale.y);
}

/***********************************************************
 *  ApplyOverlay()
 *
 *  Turns on the shader's second texture for the next draw and
 *  tells it where on the shape to put it. Like the UV scale,
 *  this has to be set for every part, or the overlay would
 *  carry over onto every shape drawn after the desk.
 ***********************************************************/
void SceneManager::ApplyOverlay(const TextureOverlay& overlay)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	int overlaySlot = -1;
	if (!overlay.textureTag.empty())
	{
		overlaySlot = FindTextureSlot(overlay.textureTag);
	}

	// no overlay on this part, or its image did not load
	if (overlaySlot < 0)
	{
		m_pShaderManager->setBoolValue(g_UseOverlayName, false);
		return;
	}

	m_pShaderManager->setBoolValue(g_UseOverlayName, true);
	m_pShaderManager->setSampler2DValue(g_OverlayTextureName, overlaySlot);
	m_pShaderManager->setVec2Value(g_OverlayCenterName, overlay.centerUV);
	m_pShaderManager->setVec2Value(g_OverlaySizeName, overlay.sizeUV);
}

/***********************************************************
 *  SetPointLight()
 *
 *  This method sends one point light's settings into the
 *  shader's pointLights array at the given index and turns
 *  that light on. The shader supports up to 5 point lights.
 ***********************************************************/
void SceneManager::SetPointLight(int index, const POINT_LIGHT& light)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	// build the start of the uniform name, for example "pointLights[0]."
	std::string prefix = "pointLights[" + std::to_string(index) + "].";

	m_pShaderManager->setVec3Value((prefix + "position").c_str(), light.position);
	m_pShaderManager->setVec3Value((prefix + "ambient").c_str(), light.ambient);
	m_pShaderManager->setVec3Value((prefix + "diffuse").c_str(), light.diffuse);
	m_pShaderManager->setVec3Value((prefix + "specular").c_str(), light.specular);
	m_pShaderManager->setBoolValue((prefix + "bActive").c_str(), true);
}

/***********************************************************
 *  SetSpotLight()
 *
 *  This method sends the spotlight's settings into the shader
 *  and turns it on. The shader compares cosines of angles to
 *  decide if a point is inside the cone, so the cone angles
 *  are converted from degrees to cosines here.
 ***********************************************************/
void SceneManager::SetSpotLight(const SPOT_LIGHT& light)
{
	if (NULL == m_pShaderManager)
	{
		return;
	}

	m_pShaderManager->setVec3Value("spotLight.position", light.position);
	m_pShaderManager->setVec3Value("spotLight.direction", light.direction);

	// cone edges, as cosines
	m_pShaderManager->setFloatValue("spotLight.cutOff",
		glm::cos(glm::radians(light.innerConeDegrees)));
	m_pShaderManager->setFloatValue("spotLight.outerCutOff",
		glm::cos(glm::radians(light.outerConeDegrees)));

	// how quickly the light fades with distance
	m_pShaderManager->setFloatValue("spotLight.constant", light.constant);
	m_pShaderManager->setFloatValue("spotLight.linear", light.linear);
	m_pShaderManager->setFloatValue("spotLight.quadratic", light.quadratic);

	// light colors
	m_pShaderManager->setVec3Value("spotLight.ambient", light.ambient);
	m_pShaderManager->setVec3Value("spotLight.diffuse", light.diffuse);
	m_pShaderManager->setVec3Value("spotLight.specular", light.specular);

	m_pShaderManager->setBoolValue("spotLight.bActive", true);
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method finds the folder that holds the images, loads
 *  every image listed in SCENE_TEXTURES into its own texture
 *  slot, reports the result in the console, and then binds
 *  the textures for rendering.
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	int texturesLoaded = 0;

	// find the folder that holds the images and report it
	std::string textureFolder = FindTextureFolder();
	std::cout << "INFO: Loading scene textures from " << textureFolder << std::endl;

	// load each image file into the next open texture slot.
	// CreateGLTexture() prints a line for every success or failure.
	for (int i = 0; i < SCENE_TEXTURE_COUNT; i++)
	{
		std::string filePath = textureFolder + SCENE_TEXTURES[i].fileName;

		if (CreateGLTexture(filePath.c_str(), SCENE_TEXTURES[i].tag))
		{
			texturesLoaded++;
		}
	}

	// print a summary so a missing image is easy to spot
	std::cout << "INFO: Loaded " << texturesLoaded << " of "
		<< SCENE_TEXTURE_COUNT << " scene textures" << std::endl;

	if (texturesLoaded < SCENE_TEXTURE_COUNT)
	{
		std::cout << "WARNING: Shapes with a missing texture will draw in gray. "
			<< "Check that the images are in a textures folder inside "
			<< "the project folder." << std::endl;
	}

	// bind the loaded textures to texture slots (16 available)
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method adds every material listed in SCENE_MATERIALS
 *  to the materials collection, so each render method can
 *  pick one by tag with SetShaderMaterial().
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	for (int i = 0; i < SCENE_MATERIAL_COUNT; i++)
	{
		m_objectMaterials.push_back(SCENE_MATERIALS[i]);
	}
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method turns on lighting in the shader and adds the
 *  four light sources defined at the top of this file. The
 *  shader keeps these values until they are changed, so this
 *  only needs to run once when the scene is prepared.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// tell the shader to use Phong lighting instead of drawing
	// the textures at full, flat brightness
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// warm key light, cool fill light, and neutral back light
	SetPointLight(0, KEY_LIGHT);
	SetPointLight(1, FILL_LIGHT);
	SetPointLight(2, BACK_LIGHT);

	// overhead desk lamp
	SetSpotLight(DESK_LAMP);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures for the 3D scene
	LoadSceneTextures();
	// define the materials for the objects in the scene
	DefineObjectMaterials();
	// add and configure the light sources for the scene
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn.
	// Only the six meshes this scene draws are loaded.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadTorusMesh();

	// create the objects and set where each one sits
	BuildSceneObjects();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene. Every
 *  object is drawn the same way, so one loop covers the
 *  whole scene no matter how many objects it holds.
 ***********************************************************/
void SceneManager::RenderScene()
{
	for (const std::unique_ptr<DeskObject>& object : m_sceneObjects)
	{
		DrawObject(*object);
	}
}

/***********************************************************
 *  BuildSceneObjects()
 *
 *  Creates every object in the scene once, when the scene is
 *  prepared. The placements at the top of this file decide
 *  where each one goes. Each object is listed in the console
 *  so it is easy to confirm what was built.
 ***********************************************************/
void SceneManager::BuildSceneObjects()
{
	m_sceneObjects.clear();

	m_sceneObjects.push_back(std::make_unique<Desk>(DESK_PLACEMENT));
	m_sceneObjects.push_back(std::make_unique<Laptop>(LAPTOP_PLACEMENT));
	m_sceneObjects.push_back(std::make_unique<CoffeeMug>(MUG_PLACEMENT));
	m_sceneObjects.push_back(std::make_unique<Smartphone>(PHONE_PLACEMENT));
	m_sceneObjects.push_back(std::make_unique<Notepad>(NOTEPAD_PLACEMENT, NOTEPAD_RING_COUNT));

	// the same Pen class used twice, with a different barrel each time
	m_sceneObjects.push_back(std::make_unique<Pen>(BLUE_PEN_PLACEMENT, SceneTags::TEX_PEN_BLUE));
	m_sceneObjects.push_back(std::make_unique<Pen>(BLACK_PEN_PLACEMENT, SceneTags::TEX_PHONE_CASE));

	int totalParts = 0;
	for (const std::unique_ptr<DeskObject>& object : m_sceneObjects)
	{
		std::cout << "INFO: Built " << object->GetName() << " from "
			<< object->GetParts().size() << " shapes" << std::endl;
		totalParts += static_cast<int>(object->GetParts().size());
	}
	std::cout << "INFO: Scene has " << m_sceneObjects.size() << " objects and "
		<< totalParts << " shapes\n" << std::endl;
}

/***********************************************************
 *  DrawObject()
 *
 *  Draws one object by setting each part's matrix, texture,
 *  overlay, and material, then drawing its mesh. This is the
 *  only drawing code in the scene, so a fix or change here
 *  applies to every object at once.
 ***********************************************************/
void SceneManager::DrawObject(const DeskObject& object)
{
	for (const ObjectPart& part : object.GetParts())
	{
		SetModelMatrix(object.GetPartModelMatrix(part));
		ApplyTexture(part.textureTag, part.uvScale);
		ApplyOverlay(part.overlay);
		SetShaderMaterial(part.materialTag);
		DrawMesh(part.mesh);
	}
}

/***********************************************************
 *  DrawMesh()
 *
 *  Draws one of the basic meshes loaded in PrepareScene().
 *  The cylinder's three flags are (top, bottom, side).
 ***********************************************************/
void SceneManager::DrawMesh(MeshType mesh)
{
	switch (mesh)
	{
	case MeshType::Plane:
		m_basicMeshes->DrawPlaneMesh();
		break;
	case MeshType::Box:
		m_basicMeshes->DrawBoxMesh();
		break;
	case MeshType::Cylinder:
		m_basicMeshes->DrawCylinderMesh();
		break;
	case MeshType::CylinderSide:
		m_basicMeshes->DrawCylinderMesh(false, false, true);
		break;
	case MeshType::CylinderTop:
		m_basicMeshes->DrawCylinderMesh(true, false, false);
		break;
	case MeshType::CylinderBottom:
		m_basicMeshes->DrawCylinderMesh(false, true, false);
		break;
	case MeshType::Cone:
		m_basicMeshes->DrawConeMesh();
		break;
	case MeshType::Sphere:
		m_basicMeshes->DrawSphereMesh();
		break;
	case MeshType::Torus:
		m_basicMeshes->DrawTorusMesh();
		break;
	}
}
