///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
//
//  MODIFIED BY: Dury Ayers
//	Milestone Three, Sept. 2026: WASD/QE movement, mouse look, scroll
//	wheel speed, and P/O perspective and orthographic switching
//	Final Project, Oct. 2026: prints the controls in the console and
//	logs camera stops, speed changes, and view changes
///////////////////////////////////////////////////////////////////////////////

#include "ViewManager.h"

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>    

#include <iomanip>

// declaration of the global variables and defines
namespace
{
	// Variables for window width and height
	const int WINDOW_WIDTH = 1000;
	const int WINDOW_HEIGHT = 800;
	const char* g_ViewName = "view";
	const char* g_ProjectionName = "projection";

	// camera object used for viewing and interacting with
	// the 3D scene
	Camera* g_pCamera = nullptr;

	// these variables are used for mouse movement processing
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// time between current frame and last frame
	float gDeltaTime = 0.0f; 
	float gLastFrame = 0.0f;

	// the following variable is false when orthographic projection
	// is off and true when it is on
	bool bOrthographicProjection = false;

	// half the height of the visible area, in world units, used
	// when building the orthographic projection box
	const float ORTHO_HALF_HEIGHT = 6.0f;

	// saved perspective camera state, so switching back from
	// orthographic returns the user to where they left off
	glm::vec3 gSavedPosition = glm::vec3(0.0f, 5.0f, 12.0f);
	float gSavedYaw = -90.0f;
	float gSavedPitch = -22.0f;

	// orthographic camera spot: straight in front of the desk, level
	// with the objects
	const glm::vec3 ORTHO_CAMERA_POSITION = glm::vec3(0.0f, 3.0f, 10.0f);

	// near and far clipping planes. 100 units holds the whole 40 x 20
	// desk from any spot the camera is likely to be.
	const float NEAR_PLANE = 0.1f;
	const float FAR_PLANE = 100.0f;

	// true while any movement key is held, so the camera's position is
	// logged once when it stops instead of every frame while it moves
	bool gWasMoving = false;

	// true while H is held, so one press prints the controls only once
	bool gHelpKeyDown = false;
}

/***********************************************************
 *  ViewManager()
 *
 *  The constructor for the class
 ***********************************************************/
ViewManager::ViewManager(
	ShaderManager *pShaderManager)
{
	// initialize the member variables
	m_pShaderManager = pShaderManager;
	m_pWindow = NULL;
	g_pCamera = new Camera();
	// default camera view parameters
	g_pCamera->Position = glm::vec3(0.0f, 5.0f, 12.0f);
	g_pCamera->Zoom = 80;

	// aim the camera using yaw and pitch instead of setting Front
	// directly, so the first mouse movement does not snap the view
	g_pCamera->Yaw = -90.0f;
	g_pCamera->Pitch = -22.0f;

	// the default sensitivity in camera.h is too slow to be usable
	g_pCamera->MouseSensitivity = 0.1f;

	// passing zero offsets rebuilds Front, Right, and Up from the
	// yaw and pitch values set above
	g_pCamera->ProcessMouseMovement(0.0f, 0.0f);
}

/***********************************************************
 *  ~ViewManager()
 *
 *  The destructor for the class
 ***********************************************************/
ViewManager::~ViewManager()
{
	// free up allocated memory
	m_pShaderManager = NULL;
	m_pWindow = NULL;
	if (NULL != g_pCamera)
	{
		delete g_pCamera;
		g_pCamera = NULL;
	}
}

/***********************************************************
 *  CreateDisplayWindow()
 *
 *  This method is used to create the main display window.
 ***********************************************************/
GLFWwindow* ViewManager::CreateDisplayWindow(const char* windowTitle)
{
	GLFWwindow* window = nullptr;

	// try to create the displayed OpenGL window
	window = glfwCreateWindow(
		WINDOW_WIDTH,
		WINDOW_HEIGHT,
		windowTitle,
		NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return NULL;
	}
	glfwMakeContextCurrent(window);

	// tell GLFW to capture all mouse events so the cursor stays
	// inside the window while the user looks around
	glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// this callback is used to receive mouse moving events
	glfwSetCursorPosCallback(window, &ViewManager::Mouse_Position_Callback);

	// this callback is used to receive mouse scroll wheel events
	glfwSetScrollCallback(window, &ViewManager::Mouse_Scroll_Callback);

	// enable blending for supporting tranparent rendering
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	m_pWindow = window;

	// show the user how to get around before the scene opens
	PrintControls();

	return(window);
}

/***********************************************************
 *  Mouse_Position_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse is moved within the active GLFW display window.
 ***********************************************************/
void ViewManager::Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos)
{
	// on the very first movement, just record the cursor position
	// so the camera does not jump from the center of the window
	if (gFirstMouse)
	{
		gLastX = (float)xMousePos;
		gLastY = (float)yMousePos;
		gFirstMouse = false;
	}

	// how far the mouse moved since the last frame; y is reversed
	// because screen coordinates increase going down
	float xOffset = (float)xMousePos - gLastX;
	float yOffset = gLastY - (float)yMousePos;

	gLastX = (float)xMousePos;
	gLastY = (float)yMousePos;

	// mouse look is locked in orthographic mode so the camera keeps
	// looking straight at the scene
	if (bOrthographicProjection == false)
	{
		g_pCamera->ProcessMouseMovement(xOffset, yOffset);
	}
}

/***********************************************************
 *  Mouse_Scroll_Callback()
 *
 *  This method is automatically called from GLFW whenever
 *  the mouse scroll wheel is used. Scrolling changes how
 *  fast the camera travels through the scene.
 ***********************************************************/
void ViewManager::Mouse_Scroll_Callback(GLFWwindow* window, double xOffset, double yOffset)
{
	// camera.h subtracts the offset from the speed, so the value
	// is negated here to make scrolling up speed the camera up.
	// camera.h also clamps the speed between 0.1 and 45.
	g_pCamera->ProcessMouseScroll(-(float)yOffset);

	std::cout << "Camera speed: " << std::fixed << std::setprecision(1)
		<< g_pCamera->MovementSpeed << std::endl;
}

/***********************************************************
 *  ProcessKeyboardEvents()
 *
 *  This method is called to process any keyboard events
 *  that may be waiting in the event queue.
 ***********************************************************/
void ViewManager::ProcessKeyboardEvents()
{
	// close the window if the escape key has been pressed
	if (glfwGetKey(m_pWindow, GLFW_KEY_ESCAPE) == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(m_pWindow, true);
	}

	// camera movement and projection switching are kept in their
	// own methods so each one stays short and easy to follow
	ProcessCameraMovement();
	ProcessProjectionKeys();
	ProcessHelpKey();
}

/***********************************************************
 *  ProcessCameraMovement()
 *
 *  Moves the camera with WASD for forward, back, left, and
 *  right, and QE for up and down. Movement is scaled by the
 *  frame time so speed is the same on any machine.
 ***********************************************************/
void ViewManager::ProcessCameraMovement()
{
	bool isMoving = false;

	// forward and backward (depth)
	if (glfwGetKey(m_pWindow, GLFW_KEY_W) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(FORWARD, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_S) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(BACKWARD, gDeltaTime);
	}

	// left and right (horizontal)
	if (glfwGetKey(m_pWindow, GLFW_KEY_A) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(LEFT, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_D) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(RIGHT, gDeltaTime);
	}

	// up and down (vertical)
	if (glfwGetKey(m_pWindow, GLFW_KEY_Q) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(UP, gDeltaTime);
	}
	if (glfwGetKey(m_pWindow, GLFW_KEY_E) == GLFW_PRESS)
	{
		g_pCamera->ProcessKeyboard(DOWN, gDeltaTime);
	}

	// check all six movement keys together for the stop log
	const int MOVEMENT_KEYS[] = { GLFW_KEY_W, GLFW_KEY_A, GLFW_KEY_S, GLFW_KEY_D, GLFW_KEY_Q, GLFW_KEY_E };
	for (int key : MOVEMENT_KEYS)
	{
		if (glfwGetKey(m_pWindow, key) == GLFW_PRESS)
		{
			isMoving = true;
		}
	}

	// log where the camera ended up once the user lets go
	if (gWasMoving && !isMoving)
	{
		LogCameraPosition("Camera stopped");
	}
	gWasMoving = isMoving;
}

/***********************************************************
 *  ProcessProjectionKeys()
 *
 *  P switches to perspective (3D) and O switches to
 *  orthographic (2D). Each switch only runs once per change,
 *  so holding the key down does not keep resetting the camera.
 ***********************************************************/
void ViewManager::ProcessProjectionKeys()
{
	// switch to orthographic if O is pressed and it is not already on
	if ((glfwGetKey(m_pWindow, GLFW_KEY_O) == GLFW_PRESS) &&
		(bOrthographicProjection == false))
	{
		// remember the perspective camera so it can be restored later
		gSavedPosition = g_pCamera->Position;
		gSavedYaw = g_pCamera->Yaw;
		gSavedPitch = g_pCamera->Pitch;

		// face the scene head on from the front, level with the objects
		g_pCamera->Position = ORTHO_CAMERA_POSITION;
		g_pCamera->Yaw = -90.0f;
		g_pCamera->Pitch = 0.0f;
		g_pCamera->ProcessMouseMovement(0.0f, 0.0f);

		bOrthographicProjection = true;
		std::cout << "View: orthographic (2D). Mouse look is locked. Press P to return to 3D." << std::endl;
	}

	// switch back to perspective if P is pressed and ortho is on
	if ((glfwGetKey(m_pWindow, GLFW_KEY_P) == GLFW_PRESS) &&
		(bOrthographicProjection == true))
	{
		// put the camera back where the user left it
		g_pCamera->Position = gSavedPosition;
		g_pCamera->Yaw = gSavedYaw;
		g_pCamera->Pitch = gSavedPitch;
		g_pCamera->ProcessMouseMovement(0.0f, 0.0f);

		bOrthographicProjection = false;
		std::cout << "View: perspective (3D)" << std::endl;
		LogCameraPosition("Camera restored");
	}
}

/***********************************************************
 *  ProcessHelpKey()
 *
 *  Prints the controls again when H is pressed. Like the P
 *  and O keys, it only acts once per press.
 ***********************************************************/
void ViewManager::ProcessHelpKey()
{
	bool helpPressed = (glfwGetKey(m_pWindow, GLFW_KEY_H) == GLFW_PRESS);
	if (helpPressed && !gHelpKeyDown)
	{
		PrintControls();
	}
	gHelpKeyDown = helpPressed;
}

/***********************************************************
 *  PrintControls()
 *
 *  Prints every control in the console so the user knows how
 *  to move around without reading the code.
 ***********************************************************/
void ViewManager::PrintControls()
{
	std::cout << "\n========== CAMERA CONTROLS ==========\n"
		<< "  W / S        move forward / back\n"
		<< "  A / D        move left / right\n"
		<< "  Q / E        move up / down\n"
		<< "  Mouse        look around (up, down, left, right)\n"
		<< "  Scroll       speed up (up) or slow down (down)\n"
		<< "  P / O        perspective (3D) / orthographic (2D) view\n"
		<< "  H            show these controls again\n"
		<< "  Esc          close the program\n"
		<< "=====================================\n" << std::endl;
}

/***********************************************************
 *  LogCameraPosition()
 *
 *  Prints the camera's position and where it is facing, so
 *  a good viewing spot can be written down and reused.
 ***********************************************************/
void ViewManager::LogCameraPosition(const char* reason)
{
	std::cout << reason << " at (" << std::fixed << std::setprecision(2)
		<< g_pCamera->Position.x << ", "
		<< g_pCamera->Position.y << ", "
		<< g_pCamera->Position.z << "), yaw "
		<< g_pCamera->Yaw << ", pitch "
		<< g_pCamera->Pitch << std::endl;
}

/***********************************************************
 *  PrepareSceneView()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void ViewManager::PrepareSceneView()
{
	glm::mat4 view;
	glm::mat4 projection;

	// per-frame timing
	float currentFrame = glfwGetTime();
	gDeltaTime = currentFrame - gLastFrame;
	gLastFrame = currentFrame;

	// process any keyboard events that may be waiting in the 
	// event queue
	ProcessKeyboardEvents();

	// get the current view matrix from the camera
	view = g_pCamera->GetViewMatrix();

	// build whichever projection matrix is currently selected
	projection = GetProjectionMatrix();

	// if the shader manager object is valid
	if (NULL != m_pShaderManager)
	{
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ViewName, view);
		// set the view matrix into the shader for proper rendering
		m_pShaderManager->setMat4Value(g_ProjectionName, projection);
		// set the view position of the camera into the shader for proper rendering
		m_pShaderManager->setVec3Value("viewPosition", g_pCamera->Position);
	}
}

/***********************************************************
 *  GetProjectionMatrix()
 *
 *  Returns an orthographic or perspective projection matrix
 *  depending on which view the user has selected.
 ***********************************************************/
glm::mat4 ViewManager::GetProjectionMatrix()
{
	float aspectRatio = (float)WINDOW_WIDTH / (float)WINDOW_HEIGHT;

	if (bOrthographicProjection == true)
	{
		// flat 2D view: objects keep the same size no matter how far
		// away they are. The width is scaled by the aspect ratio so
		// shapes are not stretched.
		float halfWidth = ORTHO_HALF_HEIGHT * aspectRatio;
		return glm::ortho(
			-halfWidth, halfWidth,
			-ORTHO_HALF_HEIGHT, ORTHO_HALF_HEIGHT,
			NEAR_PLANE, FAR_PLANE);
	}

	// 3D view: objects farther from the camera appear smaller
	return glm::perspective(
		glm::radians(g_pCamera->Zoom),
		aspectRatio,
		NEAR_PLANE, FAR_PLANE);
}
